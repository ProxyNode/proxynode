#!/bin/sh
set -e
autoreconf -if --warnings=all
